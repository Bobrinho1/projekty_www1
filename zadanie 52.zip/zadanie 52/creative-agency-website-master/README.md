# Creative Agency Website

> Simple HTML/CSS website from the [YouTube tutorial project](https://www.youtube.com/watch?v=lvYnfMOUOJY&t=274s)
![Creative Agency](/images/screenshot.png 'Creative Agency')
[LIVE PREVIEW](https://raw.githack.com/bradtraversy/creative-agency-website/master/index.html)
