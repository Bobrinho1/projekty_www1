alert("Witaj na mojej stronie. Treść jest ściśle tajna. Wciśnij ENTER")
    